/*****************************************************************************/
/* host dependent types                                                      */


/*#define BIGCASE*/


typedef UINT8 BOOLEAN;

typedef UINT8 BYTE;
typedef UINT16 WORD;
typedef UINT32 DWORD;
